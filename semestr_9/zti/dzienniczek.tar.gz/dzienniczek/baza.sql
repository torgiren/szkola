PRAGMA foreign_keys = ON;
CREATE TABLE user (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	login varchar(30),
	passwd varchar(35)
);
CREATE TABLE uczen (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	user_id INTEGER REFERENCES user(id)
);
CREATE TABLE nauczyciel (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	user_id INTEGER REFERENCES user(id)
);
CREATE TABLE przedmiot (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	nazwa varchar(30)
);
CREATE TABLE ocena (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	przedmiot_id INTEGER REFERENCES przedmiot(id),
	uczen_id INTEGER REFERENCES uczen(id),
	ocena INTEGER
);
INSERT INTO przedmiot('nazwa') values('matematyka');
INSERT INTO przedmiot('nazwa') values('fizyka');
INSERT INTO przedmiot('nazwa') values('informatyka');
INSERT INTO przedmiot('nazwa') values('polski');
