package dzienniczek::Schema::Result::User;

# Created by DBIx::Class::Schema::Loader
# DO NOT MODIFY THE FIRST PART OF THIS FILE

use strict;
use warnings;

use base 'DBIx::Class::Core';

__PACKAGE__->load_components("InflateColumn::DateTime");

=head1 NAME

dzienniczek::Schema::Result::User

=cut

__PACKAGE__->table("user");

=head1 ACCESSORS

=head2 id

  data_type: INTEGER
  default_value: undef
  is_nullable: 1
  size: undef

=head2 login

  data_type: varchar
  default_value: undef
  is_nullable: 1
  size: 30

=head2 passwd

  data_type: varchar
  default_value: undef
  is_nullable: 1
  size: 35

=cut

__PACKAGE__->add_columns(
  "id",
  {
    data_type => "INTEGER",
    default_value => undef,
    is_nullable => 1,
    size => undef,
  },
  "login",
  {
    data_type => "varchar",
    default_value => undef,
    is_nullable => 1,
    size => 30,
  },
  "passwd",
  {
    data_type => "varchar",
    default_value => undef,
    is_nullable => 1,
    size => 35,
  },
);
__PACKAGE__->set_primary_key("id");

=head1 RELATIONS

=head2 uczens

Type: has_many

Related object: L<dzienniczek::Schema::Result::Uczen>

=cut

__PACKAGE__->has_many(
  "uczens",
  "dzienniczek::Schema::Result::Uczen",
  { "foreign.user_id" => "self.id" },
);

=head2 nauczyciels

Type: has_many

Related object: L<dzienniczek::Schema::Result::Nauczyciel>

=cut

__PACKAGE__->has_many(
  "nauczyciels",
  "dzienniczek::Schema::Result::Nauczyciel",
  { "foreign.user_id" => "self.id" },
);


# Created by DBIx::Class::Schema::Loader v0.05003 @ 2013-12-26 20:07:33
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:xTvmr4Mn87MCx7SHMuI52Q


# You can replace this text with custom content, and it will be preserved on regeneration
1;
