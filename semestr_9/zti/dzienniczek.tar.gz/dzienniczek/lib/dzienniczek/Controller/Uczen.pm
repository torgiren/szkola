package dzienniczek::Controller::Uczen;
use Moose;
use namespace::autoclean;

BEGIN {extends 'Catalyst::Controller'; }

=head1 NAME

dzienniczek::Controller::Uczen - Catalyst Controller

=head1 DESCRIPTION

Catalyst Controller.

=head1 METHODS

=cut


=head2 index

=cut

sub index :Path :Args(0) {
    my ( $self, $c ) = @_;




	my $login = $c->request->params->{login};
	my $passwd = $c->request->params->{passwd};

	my $user = $c->model('DB::User')->find({passwd=>$passwd, login=>$login});
	my $id;
	my $auth = 0;
	if ($user)
	{
		$id = $user->id;
		if($c->model('DB::Uczen')->find(user_id=>$id))
		{
			$auth = 1;	
		};
	}
	else
	{
		$id = -1;
	};
#	my $auth = $c->model('DB::Nauczyciel')->find('user_id'=>$id);

	if ($auth)
	{
		$c->response->redirect('/uczen/'.$id);
	}
	else
	{
    $c->response->body('<form method="post">Login: <input type="text" name="login"><br/>
						Hasło: <input type="password" name="passwd"><br/><input type="submit">
						<br/>'.$id." - ".$auth." ; ");
	}














    #$c->response->body('Matched dzienniczek::Controller::Uczen in Uczen.');
}



sub oceny :Chained('/') :PathPart('uczen') :Args(2) {
	my ( $self, $c, $uczen, $przedmiot ) = @_;

	my @oceny = $c->model('DB::Ocena')->search("przedmiot_id"=>$przedmiot)->search("uczen_id"=>$uczen);
	my $number = scalar @oceny;
	if($number)
	{
		my $suma = 0;
		foreach (@oceny)
		{
			$suma += $_->ocena;
		}
		my $srednia = $suma / $number;
		$c->stash(oceny => [@oceny]);
		$c->stash(srednia => $srednia);
	}
	else
	{
		$c->stash(brak => 'Brak');
		$c->stash(srednia => "Brak");
	}
	$c->stash(template => 'Uczen/oceny.tt');
}

sub przedmioty :Chained('/') :PathPart('uczen') :Args(1) {
    my ( $self, $c, $id) = @_;
	$c->stash(user_id => $id);
	$c->stash(przedmioty => [$c->model('DB::Przedmiot')->all]);
	$c->stash(template => 'Uczen/przedmioty.tt'); 
}


=head1 AUTHOR

Projekt z ZTI

=head1 LICENSE

This library is free software. You can redistribute it and/or modify
it under the same terms as Perl itself.

=cut

__PACKAGE__->meta->make_immutable;

1;
