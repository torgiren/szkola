package dzienniczek::Controller::nauczyciel;
use Moose;
use namespace::autoclean;

BEGIN {extends 'Catalyst::Controller'; }

=head1 NAME

dzienniczek::Controller::nauczyciel - Catalyst Controller

=head1 DESCRIPTION

Catalyst Controller.

=head1 METHODS

=cut


=head2 index

=cut

sub index :Path :Args(0) {
    my ( $self, $c ) = @_;

#    $c->response->body('Matched dzienniczek::Controller::nauczyciel in nauczyciel.');

	my $login = $c->request->params->{login};
	my $passwd = $c->request->params->{passwd};

	my $user = $c->model('DB::User')->find({passwd=>$passwd, login=>$login});
	my $id;
	my $auth = 0;
	if ($user)
	{
		$id = $user->id;
		if($c->model('DB::Nauczyciel')->find(user_id=>$id))
		{
			$auth = 1;	
		};
	}
	else
	{
		$id = -1;
	};
#	my $auth = $c->model('DB::Nauczyciel')->find('user_id'=>$id);

	if ($auth)
	{
		$c->response->redirect('/nauczyciel/'.$id);
	}
	else
	{
    $c->response->body('<form method="post">Login: <input type="text" name="login"><br/>
						Hasło: <input type="password" name="passwd"><br/><input type="submit">
						<br/>'.$id." - ".$auth." ; ");
	}

}

sub uczniowie :Chained('/') :PathPart('nauczyciel') :Args(1) {
	my ($self, $c, $nauczyciel_id) = @_;
	my @uczniowie = $c->model('DB::Uczen')->search();
	$c->stash(uczniowie => [@uczniowie]);
	$c->stash(nauczyciel => $nauczyciel_id);
	$c->stash(template => 'Nauczyciel/uczniowie.tt');
}

sub przedmioty :Chained('/') :PathPart('nauczyciel') :Args(2) {
	my ($self, $c, $nauczyciel_id, $uczen_id) = @_;
	my @przedmioty = $c->model('DB::Przedmiot')->search();
	
	$c->stash(przedmioty=>[@przedmioty]);
	$c->stash(nauczyciel => $nauczyciel_id);
	$c->stash(uczen => $uczen_id);
	$c->stash(template=>'Nauczyciel/przedmioty.tt');

}

sub oceny :Chained('/') :PathPart('nauczyciel') :Args(3) {
	my ($self, $c, $nauczyciel_id, $uczen_id, $przedmiot_id) = @_;
#	my @oceny = $c->model('DB::Ocena')->search("przedmiot_id"=>$przedmiot_id)->search("nauczyciel_id"=>nauczyciel_id)->search("uczen_id"=>uczen_id)	

	my $ocena = $c->request->params->{ocena} || 0;
	if($ocena)
	{
		$c->model('DB::Ocena')->create({uczen_id=>$uczen_id, przedmiot_id=>$przedmiot_id, ocena=>$ocena});
	}	

	my @oceny = $c->model('DB::Ocena')->search({"przedmiot_id"=>$przedmiot_id, "uczen_id"=>$uczen_id});

	$c->stash(oceny=>[@oceny]);
	$c->stash(nauczyciel=>$nauczyciel_id);
	$c->stash(uczen=>$uczen_id);
	$c->stash(przedmiot=>$przedmiot_id);
	$c->stash(template=>'Nauczyciel/oceny.tt');

}

=head1 AUTHOR

Projekt z ZTI

=head1 LICENSE

This library is free software. You can redistribute it and/or modify
it under the same terms as Perl itself.

=cut

__PACKAGE__->meta->make_immutable;

1;
