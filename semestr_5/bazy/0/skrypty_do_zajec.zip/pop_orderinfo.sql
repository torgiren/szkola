insert into orderinfo(customer_id, date_placed, date_shipped, shipping) values(3,'03-13-2000','03-17-2000', 2.99);
insert into orderinfo(customer_id, date_placed, date_shipped, shipping) values(8,'06-23-2000','06-24-2000', 0.00);
insert into orderinfo(customer_id, date_placed, date_shipped, shipping) values(15,'09-02-2000','09-12-2000', 3.99);
insert into orderinfo(customer_id, date_placed, date_shipped, shipping) values(13,'09-03-2000','09-10-2000', 2.99);
insert into orderinfo(customer_id, date_placed, date_shipped, shipping) values(8,'07-21-2000','07-24-2000', 0.00);