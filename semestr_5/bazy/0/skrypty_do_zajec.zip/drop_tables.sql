drop table barcode;

drop table orderline;

drop table stock;

drop table orderinfo;

drop table item;

drop table customer;

drop sequence customer_customer_id_seq;

drop sequence item_item_id_seq;

drop sequence orderinfo_orderinfo_id_seq;
