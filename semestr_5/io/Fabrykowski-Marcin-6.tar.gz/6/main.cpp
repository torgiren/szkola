#include <iostream>
#include "silniacz.h"
#include "gammacz.h"
float beta(float x, float y)
{
	Gammacz gam;
	if((2*x)-(int)(2*x))
		return 0;
	if((2*y)-(int)(2*y))
		return 0;
	return gam.Policz(x)*gam.Policz(y)/gam.Policz(x+y);
};
using namespace std;
int main()
{
	float x,y;
	cout<<"Podaj x: "<<endl;
	cin>>x;
	cout<<"Podaj y: "<<endl;
	cin>>y;
	cout<<"Beta= "<<beta(x,y)<<endl;
};
