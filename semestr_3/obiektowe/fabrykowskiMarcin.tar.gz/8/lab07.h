#include <iostream>
using namespace std;
#include <math.h>
#include "cwektor.h"
