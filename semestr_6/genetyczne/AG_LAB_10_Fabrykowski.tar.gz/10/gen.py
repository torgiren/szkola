#!/usr/bin/python
import random
for i in range(300):
	print random.randint(1,50)
