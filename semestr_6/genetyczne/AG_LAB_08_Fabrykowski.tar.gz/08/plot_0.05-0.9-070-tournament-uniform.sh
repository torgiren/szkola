#!/usr/bin/gnuplot
# set terminal pngcairo  transparent enhanced font "arial,10" fontscale 1.0 size 500, 350 
# set output 'candlesticks.5.png'
set term png nocrop enhanced font arial 14 size 1920,1080
set out "data_0.05-0.9-070-tournament-uniform.png"
set boxwidth 0.2 absolute
set bars 4.0
set grid
set nokey
set multiplot layout 3,2 title "pCross=0.9 pMut=0.05 popsize=70 selector=tournament krzyzowanie=uniform"
 set style fill empty
set title "najlepszy"
plot "data_0.05-0.9-070-tournament-uniform.1.dat" using 1:3:2:6:5 with candlesticks lt 3 lw 2 title 'Quartiles',\
	'' using 1:4:4:4:4 with candlesticks lt -1 lw 2
set title "mediana"
plot "data_0.05-0.9-070-tournament-uniform.2.dat" using 1:3:2:6:5 with candlesticks lt 3 lw 2 title 'Quartiles',\
	'' using 1:4:4:4:4 with candlesticks lt -1 lw 2
set title "offline min"
plot "data_0.05-0.9-070-tournament-uniform.3.dat" using 1:3:2:6:5 with candlesticks lt 3 lw 2 title 'Quartiles',\
	'' using 1:4:4:4:4 with candlesticks lt -1 lw 2
set title "offline max"
plot "data_0.05-0.9-070-tournament-uniform.4.dat" using 1:3:2:6:5 with candlesticks lt 3 lw 2 title 'Quartiles',\
	'' using 1:4:4:4:4 with candlesticks lt -1 lw 2
set title "online"
plot "data_0.05-0.9-070-tournament-uniform.5.dat" using 1:3:2:6:5 with candlesticks lt 3 lw 2 title 'Quartiles',\
	'' using 1:4:4:4:4 with candlesticks lt -1 lw 2
set title "rozklad wynikow"
plot "wynik_0.05-0.9-070-tournament-uniform.dat"

