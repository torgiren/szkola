#!/bin/sh
mpirun -np 4 -machinefile machines src/Mrowisko
