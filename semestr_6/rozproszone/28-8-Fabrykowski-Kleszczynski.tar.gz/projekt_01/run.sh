#!/bin/sh
mpirun.mpich -np 5 -machinefile machines src/Mrowisko
