./Mrowisko|grep -i ^droga|sort -k2 -n -r|uniq  -c 
