#!/bin/sh
mpirun -np 4 -machinefile machines ./Mrowisko
