#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
float f1(float t, float u);
float jawny(float (*f)(float,float),float n,float dt,float pocz=0);
float trapezow(float (*f)(float,float),float n, float dt,float pocz=0);
int main()
{
	ofstream plik;
	ofstream plik2;
	{
		plik.open("zad1_1.dat");
		float dt=1.0f/32;
		float t;
		for(t=0.0;t<5.0f/4;t+=dt)
		{
			plik<<t<<" "<<f1(t,1)-jawny(f1,t,dt,1)<<endl;
		};
		plik.close();
	};
	{
		plik.open("zad1_3.dat");
		float dt=1.0f/32;
		float t;
		float y2=1;
		float y1=1;
		for(t=0.0;t<5.0f/4;t+=dt)
		{
/*
			float y1=jawny(f1,t,dt,1);
			float y2=jawny(f1,t,2*dt,1);
			plik<<t<<" "<<f1(t,1)-((y2+(y2-y1)))<<endl;
*/
			y1+=y1*dt;	
			y2+=y2*dt/2;	
			y2+=y2*dt/2;	
			float y=y2+(y2-y1);
			y1=y;
			y2=y;
//			cout<<t<<" "<<y<<endl;
			plik<<t<<" "<<fabs(f1(t+dt,1)-y)<<endl;
		};
		plik.close();
	};
	return 0;
};
float jawny(float (*f)(float,float),float n,float dt,float pocz)
{
	if(n<=0)
		return pocz;
	float u_1=jawny(f,n-dt,dt,pocz);
	return u_1+dt*f(n-dt,u_1);
};
float trapezow(float (*f)(float,float),float n, float dt,float pocz)
{
	if(n<=0)
		return pocz;
	float u_1=trapezow(f,n-1,dt);
	return u_1+dt*(f(n-1,0)+f(n,0))/2;
};
float f1(float t, float u)
{
	return exp(t);
};
